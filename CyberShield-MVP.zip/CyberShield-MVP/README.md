# CyberShield MVP

A responsive, browser-based cybersecurity awareness prototype for phones and laptops.

## Run it
1. Extract `CyberShield-MVP.zip`.
2. Open the `index.html` file in a modern browser (Chrome, Edge, Firefox, or Safari).
3. Try the link checker with a URL you already know. Do not open suspicious links to test them.
4. Tick items in the device checklist; completion is saved in this browser's local storage.

## Features
- Responsive dashboard
- Local heuristic link warning checker (URLs are not sent to a server)
- Device security checklist with browser-local progress
- Basic scam-awareness tips

## Important limitations
This is not antivirus, a firewall, or a reputation-based threat scanner. It does not scan files, inspect all device activity, block malicious websites, or guarantee whether a URL is safe. Heuristic checks can miss threats and can flag legitimate URLs. Do not enter real passwords, banking information, or other sensitive data into a demo.

## Suggested next steps
1. Test the UI on a phone and laptop.
2. Add accessible tests and a privacy notice.
3. If adding a backend reputation service, disclose what data is sent, minimise retention, use HTTPS, and choose a reputable provider.
4. For real device-level protection, investigate platform-supported security APIs and independent security review.
